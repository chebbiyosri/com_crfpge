<?php defined( '_JEXEC' ) or die( 'Restricted access' ); 
 
class CrfpgeViewsCalendarHtml extends JViewHtml
{
  function render()
  {
    $app = JFactory::getApplication();
   
    //display
    return parent::render();
  } 

    
}
<?php // no direct access

defined( '_JEXEC' ) or die( 'Restricted access' ); 
 
class CrfpgeControllersPrint extends CrfpgeControllersDefault
{
  public function execute()
  {
   
  }
}
<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 

function CrfpgeBuildRoute(&$query)
{
	$segments = array();
	return $segments;
}

function CrfpgeParseRoute($segments) 
{

}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  daly
 * Created: 19 janv. 2018
 */

INSERT INTO `ws_crfpge_comite` (designation,description,created,created_by) VALUES 
('Mobilisation des ressources internes et externes','Mobilisation des ressources internes et externes',CURRENT_DATE,1),
('Cadre global du Budget', 'Cadre global du Budget',CURRENT_DATE,1),
('Tresorerie et Comptabilite ', 'Tresorerie et Comptabilite ',CURRENT_DATE,1),
('Gouvernance Financière Locale', 'Gouvernance Financière Locale',CURRENT_DATE,1),
('Contrôle Interne et Externe', 'Contrôle Interne et Externe',CURRENT_DATE,1),
('Système intégré d’information financière', 'Système intégré d’information financière',CURRENT_DATE,1);

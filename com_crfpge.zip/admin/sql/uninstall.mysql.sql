DROP TABLE IF EXISTS ws_crfpge_membre;
DROP TABLE IF EXISTS ws_crfpge_action;
DROP TABLE IF EXISTS ws_crfpge_activite;
DROP TABLE IF EXISTS ws_crfpge_document;
DROP TABLE IF EXISTS ws_crfpge_institution;
DROP TABLE IF EXISTS ws_crfpge_comite;
DROP VIEW IF EXISTS  ws_crfpge_view_users;




